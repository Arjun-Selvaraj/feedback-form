import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class upload extends HttpServlet {
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String email = request.getParameter("email");
            String emp = request.getParameter("empid");
            String fb=request.getParameter("message");
            String ser1=request.getParameter("rating1");
            String ser2=request.getParameter("rating2");
            try{
           out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet upload</title>");            
            out.println("</head>");
            out.println("<body>");
           out.println("Thankyou for your valuable feedback");     
         Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/customer","arjun","arjun");
         Statement ps = con.createStatement();
         if(ser1.equals("OK")||ser1.equals("WORST")||ser1.equals("NOT GOOD")||ser2.equals("NEEDS IMPROVEMENT")||ser2.equals("NEEDS BETTERMENT"))
         {
           String sql = "insert into customerfb values ('"+email+"','"+fb+"','"+ser1+"','"+ser2+"','"+emp+"')";
           ps.executeUpdate(sql);
         }
         else
         {
             String sql= "insert into customerfb1 values ('"+email+"','"+fb+"','"+ser1+"','"+ser2+"','"+emp+"')";
             ps.executeUpdate(sql);
         }
         ResultSet rs = ps.executeQuery("SELECT * from customerfb1");
         int i=0;
         out.println("<br><br>some of the valuable feedbacks:<br><br>");
         while(rs.next()){
             String a=rs.getString("emailid");
             String b=rs.getString("fb");
             String c=rs.getString("rating1");
             String d=rs.getString("rating2");
             int k=0,a1=b.length();
             String str="";
             char[] a2=b.toCharArray();
             for(int j=0;j<a1 && k==0;j++){
               if(a2[j]==' '){
                 if(str.equals("worst")||str.equals("bad")||str.equals("waste")||str.equals("not")){
                     k=1;
                 }
                 str="";
               }
               else{
                   str+=a2[j];
               }
             }
             if(k==0){
               i+=1;  
               out.println(i+".user:"+a+"<br>feedback given:"+b+"<br>RATINGS <br>&nbsp1.for SERVICE:<b>"+c+"</b><br>&nbsp 2.for OUR Employee:<b>"+d+"</b><br><br>");
             }
             
         }
         con.close();
            } 
            catch (Exception e)
        {
            out.println(""+e);
        }
            int f1=0,f=0;
        try{
         Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection con1=DriverManager.getConnection("jdbc:derby://localhost:1527/customer","arjun","arjun");
         switch(ser1){
             case "OK":f=1;break;
             case "NOT GOOD":f=2;break;
             case "WORST":f=3;break;
             case "WELL SATISFIED":f=-2;break;
             case "SATISFIED":f=-1;break;
         }
         switch(ser2){
             case "NEEDS IMPROVEMENT":f1=1;break;
             case "NEEDS BETTERMENT":f1=2;break;
             case "GOOD":f1=-1;break;
         }
         int t=f+f1;
         Statement ps1 = con1.createStatement();
          String sql = "SELECT * FROM worker where emp='"+emp+"'";
            ResultSet rs = ps1.executeQuery(sql);
         if(rs.next()){
          //       Statement stmt = con1.createStatement();
         int q=rs.getInt("ser1");
         int w=rs.getInt("ser2");
         int e=rs.getInt("total");
         f+=q;
         f1+=w;
         t+=e;
         String sql2 = "UPDATE worker SET ser1="+f+",ser2="+f1+",total="+t+" where emp='"+emp+"'";
          ps1.executeUpdate(sql2);    
         }
         else{
         String sql1 = "insert into worker values ("+f+","+f1+","+t+",'"+emp+"')";
         ps1.executeUpdate(sql1);
                } 
            } 
            catch (Exception e)
        {
            out.println(""+e);
        } 
           out.println("</body>");
           out.println("</html>");
        }
    }

   

}
