import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class upload_serv extends HttpServlet {
    //@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String email = request.getParameter("email");
            String type = request.getParameter("typ");
            String msg=request.getParameter("complaint");
            try{
         Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/complaints","arjun","arjun");
         Statement ps = con.createStatement();
         if(type.equals("1"))
         {
           String sql = "insert into response values ('"+msg+"','"+email+"')";
           ps.executeUpdate(sql);
         }
         else if(type.equals("2")){
           String sql = "insert into timecomplaints values ('"+msg+"','"+email+"')";
           ps.executeUpdate(sql);
         }
         else if(type.equals("3")){
           String sql = "insert into dissatisfaction values ('"+msg+"','"+email+"')";
           ps.executeUpdate(sql);
         }
          else if(type.equals("4")){
           String sql = "insert into complaints values ('"+msg+"','"+email+"')";
           ps.executeUpdate(sql);
         }
         
         con.close();
            } 
            catch (Exception e)
        {
            out.println(""+e);
        }
                        
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet upload_serv</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>We will surely take necessary actions</h1>");
            out.println("<p>For further details contact:8122-XX-YYYY</p>");
            
         try
            {   
         Class.forName("org.apache.derby.jdbc.ClientDriver");
         Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/customer","arjun","arjun");
         Statement ps = con.createStatement();   
         ResultSet rs = ps.executeQuery("SELECT * from customerfb1");
         int i=0;
         out.println("<br><br>some of the valuable feedbacks:<br><br>");
         while(rs.next()){
             String a=rs.getString("emailid");
             String b=rs.getString("fb");
             String c=rs.getString("rating1");
             String d=rs.getString("rating2");
             int k=0,a1=b.length();
             String str="";
             char[] a2=b.toCharArray();
             for(int j=0;j<a1 && k==0;j++){
               if(a2[j]==' '){
                 if(str.equals("worst")||str.equals("bad")||str.equals("waste")||str.equals("not")){
                     k=1;
                 }
                 str="";
               }
               else{
                   str+=a2[j];
               }
             }
             if(k==0){
               i+=1;  
               out.println(i+".user:"+a+"<br>feedback given:"+b+"<br>RATINGS <br>&nbsp1.for SERVICE:<b>"+c+"</b><br>&nbsp 2.for OUR Employee:<b>"+d+"</b><br><br>");
             }
            
         }
            }
         catch(Exception e){
                 out.println(""+e);
                 }
            
            out.println("</body>");
            out.println("</html>");
    }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
