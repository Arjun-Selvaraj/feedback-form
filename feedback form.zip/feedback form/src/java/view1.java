import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class view1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           Class.forName("org.apache.derby.jdbc.ClientDriver");
           Connection con1=DriverManager.getConnection("jdbc:derby://localhost:1527/customer","arjun","arjun");
            Statement st = con1.createStatement();
            st = con1.createStatement();
            String name = null;
            ResultSet rs = st.executeQuery("SELECT * from worker where total = MIN(total)");
            while (rs.next()) {
			name = rs.getString(4);
			out.println(name);
		}
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet view1</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet view1 at " + name+ "</h1>");
            out.println("</body>");
            out.println("</html>");
        } 
        catch (Exception ex) {
            out.println(" "+ex);
        } 
    }

      @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
